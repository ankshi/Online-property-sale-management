module.exports = {
    user: "postgres",
    password: "sqldl",
    host: "localhost",
    port: 5432,
    database: "lab4db",
    saltedrounds: "10"
}